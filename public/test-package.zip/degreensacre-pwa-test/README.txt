De-Greenacres PWA Test Package
Generated: $(date -u)
Manifest: manifest.json
Service Worker: sw.js
Icons: icons/
Screenshots: screenshots/ (1920x1080 wide, 1080x1920 narrow, etc.)
Install: npx serve .  ->  http://localhost:3000  -> DevTools > Application > Manifest
Store packaging: Use https://www.pwabuilder.com/reportcard
